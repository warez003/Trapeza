﻿using System.Collections.Generic;

namespace NewFoodLibraryFINAL {
    public class FoodList {
        public List<Food> Foods { get; set; }
        public FoodList() => Foods = new List<Food>();
    }
}
