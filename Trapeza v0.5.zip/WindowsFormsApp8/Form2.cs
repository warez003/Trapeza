﻿using System;
using System.Windows.Forms;
using NewFoodLibraryFINAL;
using System.Drawing;

namespace WindowsFormsApp8 {
    public partial class Form2 : Form {
        private double bmr = 0;

        public Form2() {
            InitializeComponent();
            this.Icon = new Icon("icons/icoForProgram2.ico");
            this.BackgroundImage = Image.FromFile("backgroundImages/trapeza2.jpg");
        }

        private void Form2_Load(object sender, EventArgs e) {
            this.Text = "Сутощная норма";
            this.CenterToParent();
            this.FormClosed += Form2_FormClosed;
            this.AutoSize = false;
            this.SizeGripStyle = SizeGripStyle.Hide;
            this.SetAutoSizeMode(AutoSizeMode.GrowOnly);
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e) {
            if (bmr != 0) {
                Form1 main = this.Owner as Form1;
                main.textBox2.Text = Convert.ToString(bmr * 1.375);
            }
        }

        private void Button1_Click(object sender, EventArgs e) {
            try {

                if (Convert.ToInt32(textBox1.Text) < 5 || Convert.ToInt32(textBox1.Text) > 110) {
                    MessageBox.Show("Неверный вводъ возраста (Значенiе отъ 5 до 110)!");
                } else if (Convert.ToDouble(textBox2.Text) < 100 || Convert.ToDouble(textBox2.Text) > 220) {
                    MessageBox.Show("Неверный вводъ роста (Значенiе отъ 100 до 220)!");
                } else if (Convert.ToDouble(textBox3.Text) < 20 || Convert.ToDouble(textBox3.Text) > 150) {
                    MessageBox.Show("Неверный вводъ веса (Значенiе отъ 20 до 150)!");
                } else if (1==1) {
                    Calorie cal = new Calorie(comboBox1.Text, Convert.ToDouble(textBox3.Text), Convert.ToDouble(textBox2.Text), Convert.ToInt32(textBox1.Text));
                    bmr = cal.Bmr;
                    this.Close();
                }
            } catch (FormatException) {
                MessageBox.Show("Неверный вводъ!");
            }
        }
    }
}
