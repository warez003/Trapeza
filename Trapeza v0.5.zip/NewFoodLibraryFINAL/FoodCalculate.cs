﻿namespace NewFoodLibraryFINAL {
    public class FoodCalculate {
        public double SCalories { get; set; } = 0;
        public double SProteins { get; set; } = 0;
        public double SSugar { get; set; } = 0;
        public double NCalories { get; set; } = 0;
        public double NProteins { get; set; } = 0;
        public double NSugar { get; set; } = 0;
        public FoodCalculate() {

        }
        public void SetNormalParams(double normalCal, double normalProt, double normalSug) {
            NCalories = normalCal;
            NProteins = normalProt;
            NSugar = normalSug;
        }
        public void Calculate(double cal, double prot, double sug) {
            SCalories += cal;
            SProteins += prot;
            SSugar += sug;
        }
        public void AddCalories(double cal) => SCalories += cal;
    }
}
