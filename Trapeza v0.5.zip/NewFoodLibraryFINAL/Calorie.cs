﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFoodLibraryFINAL {
    public class Calorie {
        readonly string gender;
        readonly double weight;
        readonly double height;
        readonly int age;

        public double Bmr { set; get; } = 0;

        public Calorie() {
            gender = "male";
            weight = 50;
            height = 175;
            age = 18;

            CalculateCalories(gender);
        }

        public Calorie(string gender, double weight, double height, int age) {
            this.gender = gender;
            this.weight = weight;
            this.height = height;
            this.age = age;

            CalculateCalories(this.gender);
        }

        public void CalculateCalories(string gender) {
            Bmr = 88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age);
            if (gender == "female") {
                Bmr = 447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age);
            }
        }

    }
}
