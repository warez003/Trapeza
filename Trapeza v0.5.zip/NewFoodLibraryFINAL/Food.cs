﻿namespace NewFoodLibraryFINAL {
    public class Food {
		public double Sugar { get; set; } = 0; // Углеводы
		public double Proteins { get; set; } = 0; // Белки
		public double Calories { get; set; } = 0; // Калории
		public string Foodname { get; set; } = "Pickle"; // Наименование продукта
        public string ToLine => $"{Foodname}: бел({Proteins}), угл({Sugar}), кал({Calories})";

        public Food() {

		}
		public Food(double sugar, double proteins, double calories, string foodname) {
            Sugar = sugar;
			Proteins = proteins;
			Calories = calories;
			Foodname = foodname;
        }
    }
}
