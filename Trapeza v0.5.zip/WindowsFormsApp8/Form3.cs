﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp8 {
    public partial class Form3 : Form {
        public Form3() {
            InitializeComponent();
            this.Text = "Конструкторъ продуктовъ";
            this.BackgroundImage = Image.FromFile("backgroundImages/trapeza3.jpg");
            this.Icon = new Icon("icons/icoForProgram3.ico");
        }

        private void Form3_Load(object sender, EventArgs e) {
            this.CenterToParent();
            this.SetAutoSizeMode(AutoSizeMode.GrowAndShrink);
        }

        private void Button1_Click(object sender, EventArgs e) {
            pictureBox1.ImageLocation = textBox1.Text;
        }

        private void Button3_Click(object sender, EventArgs e) {
            try {

                Form1 main = this.Owner as Form1;

                if (textBox2.Text != null && textBox3.Text != null && textBox4.Text != null && textBox5.Text != null && pictureBox1.Image != null && pictureBox1.Image != pictureBox1.ErrorImage && pictureBox1.Image != pictureBox1.InitialImage) {

                    textBox3.Text = textBox3.Text.Replace('.', ',');
                    textBox4.Text = textBox4.Text.Replace('.', ',');
                    textBox5.Text = textBox5.Text.Replace('.', ',');

                    main.treeView1.Nodes.Add(new TreeNode() { Text = textBox2.Text, Name = textBox2.Text, Tag = $"Белки {textBox3.Text}\nУглеводы {textBox4.Text}\nКалорiи {textBox5.Text}", ToolTipText = $"Белки {textBox3.Text}\nУглеводы {textBox4.Text}\nКалорiи {textBox5.Text}" });
                    main.foodList.Foods.Add(new NewFoodLibraryFINAL.Food(Convert.ToDouble(textBox4.Text), Convert.ToDouble(textBox3.Text), Convert.ToDouble(textBox5.Text), textBox2.Text));
                    main.images.Images.Add(pictureBox1.Image);
                    main.treeView1.Nodes[main.treeView1.Nodes.Count - 1].ImageIndex = main.images.Images.Count - 1;
                    main.treeView1.Nodes[main.treeView1.Nodes.Count - 1].SelectedImageIndex = main.images.Images.Count - 1;

                    if (pictureBox1.Image != null && Equals(pictureBox1.Image, Image.FromFile($"bufferImages/bufferImage.jpg"))) {
                        pictureBox1.Image.Save($"bufferImages/bufferImage.jpg");
                    }
                }

            } catch (FormatException) {
                MessageBox.Show("Неверный ввод!");
            }
        }

        private void Button2_Click(object sender, EventArgs e) {
            if (File.Exists($"bufferImages/bufferImage.jpg")) {
                pictureBox1.Image = Image.FromFile($"bufferImages/bufferImage.jpg");
            }
        }
    }
}
