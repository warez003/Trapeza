﻿using System;
using System.Drawing;
using System.Windows.Forms;
using NewFoodLibraryFINAL;
using System.IO;

namespace WindowsFormsApp8 {

    public partial class Form1 : Form {
        public FoodList foodList = new FoodList();
        private readonly FoodCalculate fc = new FoodCalculate();
        private readonly FoodCalculate fcc = new FoodCalculate();
        public ImageList images = new ImageList();

        public Form1() {
            InitializeComponent();
            this.Text = "Трапеза 3000";
            this.Icon = new Icon("icons/icoForProgram.ico");
            this.BackgroundImage = Image.FromFile("backgroundImages/trapeza.jpg");
            this.Size = new Size(1043, 615);
        }

        private void Form1_Load(object sender, EventArgs e) {

            File.WriteAllText("saveInfo/saveData.txt", String.Empty);

            button1.Text = "Показать трапезы";
            button1.Enabled = false;

            foodList.Foods.AddRange(new[] { new Food(0, 23, 500, "Беконъ"), new Food(8.1, 0.9, 36, "Апельсиновый сок"), new Food(4.3, 3.5, 64, "Солянка домашняя"), new Food(0.7, 11.9, 215, "Яичница"), new Food(21.8, 1.5, 95, "Бананъ") });

            DirectoryInfo directoryInfo = new DirectoryInfo(Path.GetFullPath("images"));
            foreach (var item in directoryInfo.GetFiles()) {
                images.Images.Add(Image.FromFile(item.FullName));
            }
            treeView1.ImageList = images;

            for (int i = 0; i < foodList.Foods.Count; i++) {
                treeView1.Nodes.Add(foodList.Foods[i].Foodname).ImageIndex = i;
                treeView1.Nodes[i].SelectedImageIndex = i;
                treeView1.Nodes[i].Tag = $"Белки {foodList.Foods[i].Proteins}\nУглеводы {foodList.Foods[i].Sugar}\nКалорiи {foodList.Foods[i].Calories}";
                treeView1.Nodes[i].ToolTipText = Convert.ToString(treeView1.Nodes[i].Tag);
            }

            treeView1.ShowNodeToolTips = true;
            listBox1.Enabled = false;
            comboBox1.Items.AddRange( new[] { "Завтракъ", "Обедъ", "Ужинъ", "Перекусъ" });


            treeView1.NodeMouseClick += TreeView1_NodeMouseClick;
            comboBox1.SelectedValueChanged += ComboBox1_SelectedValueChanged;
            textBox2.Text = Convert.ToString(3400);
            textBox1.Text = Convert.ToString(0);
            textBox3.Text = Convert.ToString(0);
            textBox2.TextChanged += TextBox2_TextChanged;

            this.CenterToScreen();
            this.SetAutoSizeMode(AutoSizeMode.GrowAndShrink);
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e) {
            if (e.Button == MouseButtons.Left) {

                fcc.NCalories = Convert.ToDouble(textBox2.Text);

                if (fcc.SCalories >= fcc.NCalories) {
                    textBox1.Text = $"{fc.SCalories}";
                    textBox3.Text = $"{fcc.SCalories}";
                    comboBox1.Enabled = false;
                    treeView1.Enabled = false;
                    StreamWriter sw = new StreamWriter("saveInfo/saveData.txt", true);
                    sw.WriteLine("Калорiи за трапезы выше: " + textBox3.Text + "\n");
                    sw.Close();
                } else if (fc.SCalories < fcc.NCalories && listBox1.Enabled == true) {
                    StreamWriter sw = new StreamWriter("saveInfo/saveData.txt", true);
                    comboBox1.Enabled = true;
                    button1.Enabled = true;
                    listBox1.Items.Add(e.Node.Text);
                    sw.WriteLine(e.Node.Text);
                    fc.AddCalories(Find(e.Node.Text));
                    fcc.AddCalories(Find(e.Node.Text));
                    textBox1.Text = Convert.ToString(fc.SCalories);
                    textBox3.Text = $"{fcc.SCalories}";
                    sw.WriteLine("Калорiи: " + Find(e.Node.Text));
                    sw.WriteLine($"Калорiи за {comboBox1.Text}: " + textBox1.Text + "\n");
                    sw.Close();
                } else if (listBox1.Enabled == false) {
                    textBox1.Text = $"Выбирите прiемъ пищи";
                    textBox1.TextAlign = HorizontalAlignment.Center;
                }

            }
        }

        private void TextBox2_TextChanged(object sender, EventArgs e) {

            if (textBox2.Text.Length > 0) {
                fcc.NCalories = Convert.ToDouble(textBox2.Text);

                if (fc.SCalories < Convert.ToDouble(textBox2.Text) && listBox1.Enabled == true) {
                    comboBox1.Enabled = true;
                }

                if (fc.SCalories < fcc.NCalories) {
                    treeView1.Enabled = true;
                }
            }
        }

        private void ComboBox1_SelectedValueChanged(object sender, EventArgs e) {

            StreamWriter sw = new StreamWriter("saveInfo/saveData.txt", true);

            if (comboBox1.Text.Length > 0) {
                listBox1.Enabled = true;
            }

            sw.WriteLine('$' + comboBox1.Text.Length == 0 ? "" : comboBox1.Text + "\n");
            sw.Close();

            fc.SCalories = 0;
            listBox1.Items.Clear();
            textBox1.Text = $"{fc.SCalories}";
            
        }

        private double Find(string nameOfElem) {
            double cal = 0;
            foreach (var item in foodList.Foods) {
                if (nameOfElem == item.Foodname) {
                    cal = item.Calories;
                    break;
                }
            }
            return cal;
        }

        private void Button1_Click(object sender, EventArgs e) {
            listBox2.Items.Clear();
            if (File.Exists("saveInfo/saveData.txt")) {
                StreamReader sr = new StreamReader("saveInfo/saveData.txt");
                while (!sr.EndOfStream) {
                    listBox2.Items.Add(sr.ReadLine());
                }
                sr.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e) {
            Form2 form = new Form2() { Owner = this };
            form.ShowDialog();
        }

        private void Button3_Click(object sender, EventArgs e) {
            Form3 form3 = new Form3() { Owner = this };
            form3.ShowDialog();
        }
    }
}
